# plugin.video.nba.video
NBA.com video plugin developed by stacked. I've provided a fix to enable streams to function as of Feb '15.

Kodi official forum for this plugin.  Post here for support:

http://forum.kodi.tv/showthread.php?tid=42321&pid=1928431#pid1928431
